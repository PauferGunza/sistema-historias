# Manual do Usuário - Site de Histórias

## Introdução

Bem-vindo ao seu site pessoal para guardar as histórias que sua namorada conta! Este manual explica como utilizar todas as funcionalidades disponíveis no sistema.

## Acesso ao Site

O site está disponível através do seguinte link:
https://5000-igjtujvjyvmictrbokuan-04fb1dcb.manusvm.computer

## Funcionalidades Principais

### 1. Página Inicial

Na página inicial, você encontrará:
- Lista de todas as histórias cadastradas
- Campo de busca para encontrar histórias específicas
- Filtro por categorias
- Botão para adicionar novas histórias

### 2. Adicionando uma Nova História

Para adicionar uma nova história:
1. Clique no botão "Nova História" na página inicial
2. Preencha o título da história
3. Selecione uma categoria existente ou crie uma nova
4. Escreva o conteúdo da história no campo de texto
5. Se desejar, adicione anexos (imagens ou outros arquivos)
6. Clique em "Salvar História"

### 3. Gerenciando Categorias

Para gerenciar as categorias:
1. Clique em "Categorias" no menu superior
2. Visualize todas as categorias existentes
3. Adicione novas categorias clicando em "Nova Categoria"
4. Edite ou exclua categorias existentes usando os botões de ação

### 4. Visualizando uma História

Para visualizar uma história:
1. Clique em "Ver história" em qualquer card na página inicial
2. Veja o conteúdo completo, categoria e data de criação
3. Acesse os anexos disponíveis
4. Use as opções para editar, compartilhar ou excluir a história

### 5. Compartilhando Histórias

Para compartilhar uma história:
1. Abra a história que deseja compartilhar
2. Clique no botão "Compartilhar" no menu de opções
3. Um link de compartilhamento será gerado
4. Copie o link e envie para quem desejar
5. Para desativar o compartilhamento, clique em "Gerenciar compartilhamento"

### 6. Buscando Histórias

Para buscar histórias:
1. Digite palavras-chave no campo de busca no topo da página
2. Pressione Enter ou clique em "Buscar"
3. Os resultados mostrarão histórias que contenham as palavras buscadas no título ou conteúdo

### 7. Anexando Arquivos

Para anexar arquivos a uma história:
1. Ao criar ou editar uma história, clique em "Escolher arquivos" na seção de anexos
2. Selecione um ou mais arquivos do seu computador
3. Os arquivos serão enviados junto com a história ao salvar

## Dicas de Uso

- Organize suas histórias em categorias para facilitar a busca
- Use palavras-chave significativas no título para encontrar histórias rapidamente
- Anexe imagens relacionadas para enriquecer suas memórias
- Compartilhe histórias especiais com sua namorada através do link de compartilhamento

## Suporte

Se encontrar algum problema ou tiver dúvidas sobre o uso do site, entre em contato para obter suporte.

Aproveite seu site de histórias!
