from flask import Blueprint, request, jsonify, current_app, send_from_directory
import os
import uuid
from datetime import datetime
import json
from werkzeug.utils import secure_filename
from src.models.story import db, Story, Category, Attachment

# Criar blueprint para as rotas de histórias
story_bp = Blueprint('story', __name__)

# Configuração para upload de arquivos
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf', 'doc', 'docx', 'txt'}

# Garantir que a pasta de uploads exista
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Rota para listar todas as histórias
@story_bp.route('/stories', methods=['GET'])
def get_stories():
    search_term = request.args.get('search', '')
    category_id = request.args.get('category', None)
    
    query = Story.query
    
    # Filtrar por categoria se especificado
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    # Buscar por termo se especificado
    if search_term:
        query = query.filter(Story.title.contains(search_term) | 
                            Story.content.contains(search_term))
    
    stories = query.order_by(Story.created_at.desc()).all()
    
    result = []
    for story in stories:
        story_data = {
            'id': story.id,
            'title': story.title,
            'content': story.content[:200] + '...' if len(story.content) > 200 else story.content,
            'created_at': story.created_at.strftime('%d/%m/%Y %H:%M'),
            'updated_at': story.updated_at.strftime('%d/%m/%Y %H:%M'),
            'is_shared': story.is_shared,
            'category': story.category.name if story.category else 'Sem categoria',
            'attachments_count': len(story.attachments)
        }
        result.append(story_data)
    
    return jsonify(result)

# Rota para obter uma história específica
@story_bp.route('/stories/<int:story_id>', methods=['GET'])
def get_story(story_id):
    story = Story.query.get_or_404(story_id)
    
    attachments = []
    for attachment in story.attachments:
        attachments.append({
            'id': attachment.id,
            'filename': attachment.filename,
            'file_type': attachment.file_type,
            'uploaded_at': attachment.uploaded_at.strftime('%d/%m/%Y %H:%M')
        })
    
    result = {
        'id': story.id,
        'title': story.title,
        'content': story.content,
        'created_at': story.created_at.strftime('%d/%m/%Y %H:%M'),
        'updated_at': story.updated_at.strftime('%d/%m/%Y %H:%M'),
        'is_shared': story.is_shared,
        'share_token': story.share_token if story.is_shared else None,
        'category_id': story.category_id,
        'category_name': story.category.name if story.category else 'Sem categoria',
        'attachments': attachments
    }
    
    return jsonify(result)

# Rota para criar uma nova história
@story_bp.route('/stories', methods=['POST'])
def create_story():
    data = request.form
    
    if not data.get('title') or not data.get('content'):
        return jsonify({'error': 'Título e conteúdo são obrigatórios'}), 400
    
    new_story = Story(
        title=data.get('title'),
        content=data.get('content'),
        category_id=data.get('category_id') if data.get('category_id') else None,
        is_shared=False
    )
    
    db.session.add(new_story)
    db.session.commit()
    
    # Processar arquivos anexados, se houver
    files = request.files.getlist('files')
    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # Gerar nome único para evitar conflitos
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            file.save(file_path)
            
            # Determinar o tipo de arquivo
            file_extension = filename.rsplit('.', 1)[1].lower()
            if file_extension in ['png', 'jpg', 'jpeg', 'gif']:
                file_type = 'image'
            elif file_extension in ['pdf']:
                file_type = 'pdf'
            elif file_extension in ['doc', 'docx']:
                file_type = 'document'
            else:
                file_type = 'other'
            
            # Criar registro de anexo
            attachment = Attachment(
                filename=filename,
                file_path=os.path.join('uploads', unique_filename),
                file_type=file_type,
                story_id=new_story.id
            )
            db.session.add(attachment)
    
    db.session.commit()
    
    return jsonify({'id': new_story.id, 'message': 'História criada com sucesso'}), 201

# Rota para atualizar uma história
@story_bp.route('/stories/<int:story_id>', methods=['PUT'])
def update_story(story_id):
    story = Story.query.get_or_404(story_id)
    data = request.form
    
    if data.get('title'):
        story.title = data.get('title')
    
    if data.get('content'):
        story.content = data.get('content')
    
    if data.get('category_id'):
        story.category_id = data.get('category_id')
    
    story.updated_at = datetime.utcnow()
    
    # Processar arquivos anexados, se houver
    files = request.files.getlist('files')
    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # Gerar nome único para evitar conflitos
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            file.save(file_path)
            
            # Determinar o tipo de arquivo
            file_extension = filename.rsplit('.', 1)[1].lower()
            if file_extension in ['png', 'jpg', 'jpeg', 'gif']:
                file_type = 'image'
            elif file_extension in ['pdf']:
                file_type = 'pdf'
            elif file_extension in ['doc', 'docx']:
                file_type = 'document'
            else:
                file_type = 'other'
            
            # Criar registro de anexo
            attachment = Attachment(
                filename=filename,
                file_path=os.path.join('uploads', unique_filename),
                file_type=file_type,
                story_id=story.id
            )
            db.session.add(attachment)
    
    db.session.commit()
    
    return jsonify({'message': 'História atualizada com sucesso'})

# Rota para excluir uma história
@story_bp.route('/stories/<int:story_id>', methods=['DELETE'])
def delete_story(story_id):
    story = Story.query.get_or_404(story_id)
    
    # Excluir arquivos físicos
    for attachment in story.attachments:
        file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', attachment.file_path)
        if os.path.exists(file_path):
            os.remove(file_path)
    
    db.session.delete(story)
    db.session.commit()
    
    return jsonify({'message': 'História excluída com sucesso'})

# Rota para compartilhar uma história
@story_bp.route('/stories/<int:story_id>/share', methods=['POST'])
def share_story(story_id):
    story = Story.query.get_or_404(story_id)
    
    # Gerar token de compartilhamento se não existir
    if not story.share_token:
        story.share_token = uuid.uuid4().hex
    
    story.is_shared = True
    db.session.commit()
    
    share_url = f"/shared/{story.share_token}"
    
    return jsonify({
        'message': 'História compartilhada com sucesso',
        'share_token': story.share_token,
        'share_url': share_url
    })

# Rota para desativar compartilhamento
@story_bp.route('/stories/<int:story_id>/unshare', methods=['POST'])
def unshare_story(story_id):
    story = Story.query.get_or_404(story_id)
    story.is_shared = False
    db.session.commit()
    
    return jsonify({'message': 'Compartilhamento desativado com sucesso'})

# Rota para acessar história compartilhada
@story_bp.route('/shared/<share_token>', methods=['GET'])
def view_shared_story(share_token):
    story = Story.query.filter_by(share_token=share_token, is_shared=True).first_or_404()
    
    attachments = []
    for attachment in story.attachments:
        attachments.append({
            'id': attachment.id,
            'filename': attachment.filename,
            'file_type': attachment.file_type,
            'uploaded_at': attachment.uploaded_at.strftime('%d/%m/%Y %H:%M')
        })
    
    result = {
        'id': story.id,
        'title': story.title,
        'content': story.content,
        'created_at': story.created_at.strftime('%d/%m/%Y %H:%M'),
        'category_name': story.category.name if story.category else 'Sem categoria',
        'attachments': attachments
    }
    
    return jsonify(result)

# Rota para listar categorias
@story_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = Category.query.all()
    result = []
    
    for category in categories:
        result.append({
            'id': category.id,
            'name': category.name,
            'description': category.description,
            'stories_count': len(category.stories)
        })
    
    return jsonify(result)

# Rota para criar categoria
@story_bp.route('/categories', methods=['POST'])
def create_category():
    data = request.json
    
    if not data or not data.get('name'):
        return jsonify({'error': 'Nome da categoria é obrigatório'}), 400
    
    new_category = Category(
        name=data.get('name'),
        description=data.get('description', '')
    )
    
    db.session.add(new_category)
    db.session.commit()
    
    return jsonify({
        'id': new_category.id,
        'message': 'Categoria criada com sucesso'
    }), 201

# Rota para acessar arquivos anexados
@story_bp.route('/attachments/<int:attachment_id>', methods=['GET'])
def get_attachment(attachment_id):
    attachment = Attachment.query.get_or_404(attachment_id)
    
    # Extrair o nome do arquivo do caminho
    filename = os.path.basename(attachment.file_path)
    directory = os.path.dirname(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', attachment.file_path))
    
    return send_from_directory(directory, filename, as_attachment=True)

# Rota para excluir um anexo
@story_bp.route('/attachments/<int:attachment_id>', methods=['DELETE'])
def delete_attachment(attachment_id):
    attachment = Attachment.query.get_or_404(attachment_id)
    
    # Excluir arquivo físico
    file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'static', attachment.file_path)
    if os.path.exists(file_path):
        os.remove(file_path)
    
    db.session.delete(attachment)
    db.session.commit()
    
    return jsonify({'message': 'Anexo excluído com sucesso'})
