# Este arquivo permite que o diretório routes seja tratado como um pacote Python
