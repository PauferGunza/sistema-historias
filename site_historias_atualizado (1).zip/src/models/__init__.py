# Este arquivo permite que o diretório models seja tratado como um pacote Python
